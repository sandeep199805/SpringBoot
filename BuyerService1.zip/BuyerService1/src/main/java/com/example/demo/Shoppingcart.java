package com.example.demo;

import java.util.List;

import javax.persistence.*;

import org.springframework.stereotype.Repository;

@Entity
public class Shoppingcart {
@Id
private int cart_Id;

private  int productid;
public int getProductid() {
	return productid;
}


public void setProductid(int productid) {
	this.productid = productid;
}
private int quantity;
private float total_price;
@ManyToOne
@JoinColumn(name="buyerid")
private Buyer user;

public int getQuantity() {
	return quantity;
}


public void setQuantity(int quantity) {
	this.quantity = quantity;
}


public Buyer getUser() {
	return user;
}


public void setUser(Buyer user) {
	this.user = user;
}


//productId
public Shoppingcart() {
	System.out.println("ShoppingCart Object Has been Created");
}









public Shoppingcart(int cart_Id, int productid, int quantity, float total_price, Buyer user) {
	super();
	this.cart_Id = cart_Id;
	this.productid = productid;
	this.quantity = quantity;
	this.total_price = total_price;
	this.user = user;
}





@Override
public String toString() {
	return "Shoppingcart [cart_Id=" + cart_Id + ", productid=" + productid + ", quantity=" + quantity + ", total_price="
			+ total_price + ", user=" + user + "]";
}


public int getCart_Id() {
	return cart_Id;
}

public void setCart_Id(int cart_Id) {
	this.cart_Id = cart_Id;
}
public int getQuatity() {
	return quantity;
}
public void setQuatity(int quantity) {
	this.quantity = quantity;
}
public float getTotal_price() {
	return total_price;
}
public void setTotal_price(float total_price) {
	this.total_price = total_price;
}

}
