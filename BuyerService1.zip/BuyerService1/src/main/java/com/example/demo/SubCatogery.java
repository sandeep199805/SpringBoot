package com.example.demo;

import javax.persistence.*;

@Entity
public class SubCatogery {
	@Id
	private int subcategory_id;
	private String subcategory_name;
	/*@ManyToOne//category_id
	private Category category;*/
	private String brief_details;
	private float GST;
	public int getSubcategory_id() {
		return subcategory_id;
	}
	public void setSubcategory_id(int subcategory_id) {
		this.subcategory_id = subcategory_id;
	}
	public String getSubcategory_name() {
		return subcategory_name;
	}
	public void setSubcategory_name(String subcategory_name) {
		this.subcategory_name = subcategory_name;
	}
	public String getBrief_details() {
		return brief_details;
	}
	public void setBrief_details(String brief_details) {
		this.brief_details = brief_details;
	}
	public float getGST() {
		return GST;
	}
	public void setGST(float gST) {
		GST = gST;
	}
	@Override
	public String toString() {
		return "SubCatogery [subcategory_id=" + subcategory_id + ", subcategory_name=" + subcategory_name
				+ ", brief_details=" + brief_details + ", GST=" + GST + "]";
	}
	public SubCatogery(int subcategory_id, String subcategory_name, String brief_details, float gST) {
		super();
		this.subcategory_id = subcategory_id;
		this.subcategory_name = subcategory_name;
		this.brief_details = brief_details;
		GST = gST;
	}
	public SubCatogery() {
		System.out.println("Sub_Category Object has been created");
	}
	

}
