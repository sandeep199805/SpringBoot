package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.service.BuyerService;

@RestController
public class BuyerController {
	@Autowired
	public BuyerService byserv;
	@GetMapping("/getAll")
	public List<Product> getProducts()
	{
		return byserv.getProducts();
	}
	@GetMapping("/gellAllUsers")
	public List<Buyer> getUsers()
	{
		return byserv.getUsers();
	}
	@PostMapping("/createUser")
	public String addProduct(@RequestBody Buyer buyer)
	{
		return byserv.addProduct(buyer);
	}
	@PostMapping("/addCart")
	public String addCart(@RequestBody Shoppingcart scart)
	{
		return byserv.addCart(scart);
	}
	@GetMapping("/getcartitems")
	public List<Shoppingcart> cartItems()
	{
		return byserv.cartItems();
	}
	@DeleteMapping("/Deletecartitem/{id}")
	public String deleteCartItem(@PathVariable("id") int productid)
	{
		return byserv.deleteCartItem(productid);
	}

}
